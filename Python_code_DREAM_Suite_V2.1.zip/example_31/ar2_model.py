import numpy as np

############################
### Case study 31
############################
def ar2_model(par, plugin):

    # Returns zero value
    y = np.zeros(plugin['N'])  # Initialize the result array with zeros
    # --> residua should then be distributed according to GL+ or SGT distribution 

    return y
